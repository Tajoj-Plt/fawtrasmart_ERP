@extends('hr::master')

@section('title')
    تقرير المرتبات التفصيلي
@stop

@section('css')
<style>
    .salaries-report-page {
        padding: 20px;
        background: #f8f9fa;
        min-height: 100vh;
    }

    .page-header {
        background: white;
        padding: 20px;
        border-radius: 8px;
        margin-bottom: 20px;
        box-shadow: 0 2px 4px rgba(0,0,0,0.05);
    }

    .page-header h3 {
        margin: 0;
        color: #333;
        font-size: 24px;
        display: flex;
        align-items: center;
        gap: 10px;
    }

    .filters-card {
        background: white;
        padding: 25px;
        border-radius: 8px;
        margin-bottom: 20px;
        box-shadow: 0 2px 4px rgba(0,0,0,0.05);
    }

    .filters-title {
        font-size: 18px;
        color: #007bff;
        margin-bottom: 20px;
        font-weight: 600;
        display: flex;
        align-items: center;
        gap: 8px;
    }

    .form-row {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: 20px;
        margin-bottom: 20px;
    }

    .form-group label {
        display: block;
        margin-bottom: 8px;
        color: #333;
        font-weight: 500;
        font-size: 14px;
    }

    .form-control {
        width: 100%;
        padding: 10px 15px;
        border: 1px solid #ddd;
        border-radius: 6px;
        font-size: 14px;
        transition: border-color 0.2s;
    }

    .form-control:focus {
        outline: none;
        border-color: #007bff;
        box-shadow: 0 0 0 3px rgba(0,123,255,0.1);
    }

    .btn-primary {
        background: #007bff;
        color: white;
        border: none;
        padding: 12px 30px;
        border-radius: 6px;
        font-size: 14px;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.2s;
    }

    .btn-primary:hover {
        background: #0056b3;
        transform: translateY(-2px);
        box-shadow: 0 4px 8px rgba(0,123,255,0.3);
    }

    .btn-secondary {
        background: #6c757d;
        color: white;
        border: none;
        padding: 12px 30px;
        border-radius: 6px;
        font-size: 14px;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.2s;
        margin-right: 10px;
    }

    .btn-secondary:hover {
        background: #545b62;
    }

    .totals-card {
        background: white;
        padding: 20px;
        border-radius: 8px;
        margin-bottom: 20px;
        box-shadow: 0 2px 4px rgba(0,0,0,0.05);
    }

    .totals-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 15px;
    }

    .total-item {
        padding: 20px;
        background: #f8f9fa;
        border-radius: 8px;
        border-right: 4px solid #007bff;
    }

    .total-label {
        font-size: 13px;
        color: #6c757d;
        margin-bottom: 5px;
    }

    .total-value {
        font-size: 24px;
        font-weight: 700;
        color: #007bff;
    }

    .data-card {
        background: white;
        padding: 0;
        border-radius: 8px;
        box-shadow: 0 2px 4px rgba(0,0,0,0.05);
        overflow: hidden;
    }

    .table-responsive {
        overflow-x: auto;
    }

    .data-table {
        width: 100%;
        border-collapse: collapse;
    }

    .data-table thead {
        background: #007bff;
        color: white;
    }

    .data-table th {
        padding: 15px;
        text-align: right;
        font-weight: 600;
        font-size: 14px;
        white-space: nowrap;
    }

    .data-table td {
        padding: 15px;
        text-align: right;
        border-bottom: 1px solid #f0f0f0;
        font-size: 14px;
    }

    .data-table tbody tr:hover {
        background: #f8f9fa;
    }

    .status-badge {
        padding: 5px 12px;
        border-radius: 20px;
        font-size: 12px;
        font-weight: 600;
        display: inline-block;
    }

    .status-paid {
        background: #d4edda;
        color: #155724;
    }

    .status-pending {
        background: #fff3cd;
        color: #856404;
    }

    .status-cancelled {
        background: #f8d7da;
        color: #721c24;
    }

    .no-data {
        padding: 50px;
        text-align: center;
        color: #6c757d;
    }

    .amount-positive {
        color: #28a745;
        font-weight: 600;
    }

    .amount-negative {
        color: #dc3545;
        font-weight: 600;
    }
</style>
@stop

@section('content')
<div class="salaries-report-page">
    <!-- Page Header -->
    <div class="page-header">
        <h3>
            <i class="feather icon-dollar-sign"></i>
            تقرير المرتبات التفصيلي
        </h3>
    </div>

    <!-- Filters Card -->
    <div class="filters-card">
        <div class="filters-title">
            <i class="feather icon-filter"></i>
            الفلاتر
        </div>
        
        <form method="GET" action="{{ route('hr.reports.salaries') }}">
            <div class="form-row">
                <div class="form-group">
                    <label>القسم</label>
                    <select name="department_id" class="form-control">
                        <option value="">جميع الأقسام</option>
                        @foreach($departments as $department)
                            <option value="{{ $department->id }}" {{ request('department_id') == $department->id ? 'selected' : '' }}>
                                {{ $department->name }}
                            </option>
                        @endforeach
                    </select>
                </div>

                <div class="form-group">
                    <label>الموظف</label>
                    <select name="employee_id" class="form-control">
                        <option value="">جميع الموظفين</option>
                        @foreach($employees as $employee)
                            <option value="{{ $employee->id }}" {{ request('employee_id') == $employee->id ? 'selected' : '' }}>
                                {{ $employee->full_name }}
                            </option>
                        @endforeach
                    </select>
                </div>

                <div class="form-group">
                    <label>الفرع</label>
                    <select name="branch_id" class="form-control">
                        <option value="">جميع الفروع</option>
                        @foreach($branches as $branch)
                            <option value="{{ $branch->id }}" {{ request('branch_id') == $branch->id ? 'selected' : '' }}>
                                {{ $branch->name }}
                            </option>
                        @endforeach
                    </select>
                </div>

                <div class="form-group">
                    <label>الحالة</label>
                    <select name="status" class="form-control">
                        <option value="">جميع الحالات</option>
                        <option value="paid" {{ request('status') == 'paid' ? 'selected' : '' }}>مدفوع</option>
                        <option value="pending" {{ request('status') == 'pending' ? 'selected' : '' }}>قيد الانتظار</option>
                        <option value="cancelled" {{ request('status') == 'cancelled' ? 'selected' : '' }}>ملغي</option>
                    </select>
                </div>

                <div class="form-group">
                    <label>من شهر</label>
                    <input type="month" name="from_date" class="form-control" value="{{ request('from_date', $fromDate->format('Y-m')) }}">
                </div>

                <div class="form-group">
                    <label>إلى شهر</label>
                    <input type="month" name="to_date" class="form-control" value="{{ request('to_date', $toDate->format('Y-m')) }}">
                </div>
            </div>

            <div style="display: flex; gap: 10px;">
                <button type="submit" name="fetch_data" value="1" class="btn-primary">
                    <i class="feather icon-search"></i>
                    عرض التقرير
                </button>
                <a href="{{ route('hr.reports.salaries') }}" class="btn-secondary">
                    <i class="feather icon-refresh-cw"></i>
                    إعادة تعيين
                </a>
            </div>
        </form>
    </div>

    <!-- Totals Card -->
    @if(request('fetch_data'))
    <div class="totals-card">
        <div class="totals-grid">
            <div class="total-item">
                <div class="total-label">إجمالي الموظفين</div>
                <div class="total-value">{{ $totals['total_employees'] }}</div>
            </div>
            <div class="total-item">
                <div class="total-label">إجمالي الراتب الأساسي</div>
                <div class="total-value">{{ number_format($totals['total_basic_salary'], 2) }}</div>
            </div>
            <div class="total-item">
                <div class="total-label">إجمالي البدلات</div>
                <div class="total-value" style="color: #28a745;">{{ number_format($totals['total_allowances'], 2) }}</div>
            </div>
            <div class="total-item">
                <div class="total-label">إجمالي الخصومات</div>
                <div class="total-value" style="color: #dc3545;">{{ number_format($totals['total_deductions'], 2) }}</div>
            </div>
            <div class="total-item">
                <div class="total-label">صافي المرتبات</div>
                <div class="total-value" style="color: #17a2b8;">{{ number_format($totals['total_net_salary'], 2) }}</div>
            </div>
        </div>
    </div>

    <!-- Data Table -->
    <div class="data-card">
        <div class="table-responsive">
            @if($salariesData->count() > 0)
            <table class="data-table">
                <thead>
                    <tr>
                        <th>الشهر</th>
                        <th>كود الموظف</th>
                        <th>اسم الموظف</th>
                        <th>القسم</th>
                        <th>الراتب الأساسي</th>
                        <th>البدلات</th>
                        <th>الخصومات</th>
                        <th>صافي الراتب</th>
                        <th>الحالة</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($salariesData as $salary)
                    <tr>
                        <td>{{ $salary->month }}</td>
                        <td>{{ $salary->employee_code }}</td>
                        <td>{{ $salary->employee_name }}</td>
                        <td>{{ $salary->department_name ?? 'غير محدد' }}</td>
                        <td>{{ number_format($salary->basic_salary, 2) }}</td>
                        <td class="amount-positive">{{ number_format($salary->total_allowances, 2) }}</td>
                        <td class="amount-negative">{{ number_format($salary->total_deductions, 2) }}</td>
                        <td><strong>{{ number_format($salary->net_salary, 2) }}</strong></td>
                        <td>
                            @if($salary->status == 'paid')
                                <span class="status-badge status-paid">مدفوع</span>
                            @elseif($salary->status == 'pending')
                                <span class="status-badge status-pending">قيد الانتظار</span>
                            @else
                                <span class="status-badge status-cancelled">ملغي</span>
                            @endif
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
            @else
            <div class="no-data">
                <i class="feather icon-inbox" style="font-size: 48px; color: #ddd; margin-bottom: 10px;"></i>
                <p>لا توجد بيانات متاحة</p>
            </div>
            @endif
        </div>
    </div>
    @endif
</div>
@stop

@section('js')
@stop
