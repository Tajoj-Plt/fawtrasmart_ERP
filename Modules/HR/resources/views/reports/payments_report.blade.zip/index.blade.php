@extends('hr::master')

@section('title')
    تقارير الموارد البشرية
@stop

@section('css')
<style>
    .reports-page {
        padding: 30px;
        background: #f8f9fa;
        min-height: 100vh;
    }

    .page-header {
        background: white;
        padding: 25px;
        border-radius: 8px;
        box-shadow: 0 2px 4px rgba(0,0,0,0.05);
        margin-bottom: 30px;
    }

    .page-header h2 {
        color: #333;
        margin: 0;
        font-size: 28px;
        font-weight: 600;
    }

    .reports-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(500px, 1fr));
        gap: 25px;
    }

    .report-section {
        background: white;
        border-radius: 8px;
        padding: 0;
        box-shadow: 0 2px 8px rgba(0,0,0,0.08);
        overflow: hidden;
    }

    .section-header {
        background: #007bff;
        color: white;
        padding: 20px 25px;
        border-bottom: 3px solid #0056b3;
    }

    .section-header h3 {
        margin: 0;
        font-size: 20px;
        font-weight: 600;
        display: flex;
        align-items: center;
        gap: 10px;
    }

    .section-header i {
        font-size: 24px;
    }

    .report-list {
        padding: 15px;
    }

    .report-item {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 18px 15px;
        border-bottom: 1px solid #f0f0f0;
        transition: all 0.2s;
    }

    .report-item:last-child {
        border-bottom: none;
    }

    .report-item:hover {
        background: #f8f9fa;
    }

    .report-info {
        display: flex;
        align-items: center;
        gap: 15px;
    }

    .report-icon {
        width: 45px;
        height: 45px;
        background: #e7f3ff;
        border-radius: 8px;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #007bff;
        font-size: 20px;
    }

    .report-details h4 {
        margin: 0 0 5px 0;
        font-size: 16px;
        color: #333;
        font-weight: 600;
    }

    .report-details p {
        margin: 0;
        font-size: 13px;
        color: #6c757d;
    }

    .view-btn {
        background: #007bff;
        color: white;
        border: none;
        padding: 10px 25px;
        border-radius: 6px;
        font-size: 14px;
        font-weight: 500;
        cursor: pointer;
        transition: all 0.2s;
        text-decoration: none;
        display: inline-flex;
        align-items: center;
        gap: 8px;
    }

    .view-btn:hover {
        background: #0056b3;
        color: white;
        transform: translateY(-2px);
        box-shadow: 0 4px 8px rgba(0,123,255,0.3);
    }

    .view-btn i {
        font-size: 16px;
    }
</style>
@stop

@section('content')
<div class="reports-page">
    <div class="page-header">
        <h2>📊 تقارير الموارد البشرية</h2>
    </div>

    <div class="reports-grid">
        <!-- قسم تقارير الحضور -->
        <div class="report-section">
            <div class="section-header">
                <h3>
                    <i class="feather icon-clock"></i>
                    تقارير الحضور
                </h3>
            </div>
            <div class="report-list">
                <div class="report-item">
                    <div class="report-info">
                        <div class="report-icon">
                            <i class="feather icon-calendar"></i>
                        </div>
                        <div class="report-details">
                            <h4>تقرير الحضور التفصيلي</h4>
                            <p>تقرير حضور الموظفين حسب القسم والتاريخ</p>
                        </div>
                    </div>
                    <a href="{{ route('hr.reports.attendance') }}" class="view-btn">
                        عرض التقرير
                        <i class="feather icon-arrow-left"></i>
                    </a>
                </div>

                <div class="report-item">
                    <div class="report-info">
                        <div class="report-icon">
                            <i class="feather icon-user-check"></i>
                        </div>
                        <div class="report-details">
                            <h4>ملخص حضور الموظف</h4>
                            <p>ملخص شهري لحضور الموظف بالتفصيل</p>
                        </div>
                    </div>
                    <a href="{{ route('hr.reports.attendance') }}" class="view-btn">
                        عرض التقرير
                        <i class="feather icon-arrow-left"></i>
                    </a>
                </div>

                <div class="report-item">
                    <div class="report-info">
                        <div class="report-icon">
                            <i class="feather icon-alert-circle"></i>
                        </div>
                        <div class="report-details">
                            <h4>تقرير التأخيرات</h4>
                            <p>تقرير بحالات التأخير والانصراف المبكر</p>
                        </div>
                    </div>
                    <a href="{{ route('hr.reports.attendance') }}" class="view-btn">
                        عرض التقرير
                        <i class="feather icon-arrow-left"></i>
                    </a>
                </div>
            </div>
        </div>

        <!-- قسم تقارير المرتبات -->
        <div class="report-section">
            <div class="section-header">
                <h3>
                    <i class="feather icon-dollar-sign"></i>
                    تقارير المرتبات
                </h3>
            </div>
            <div class="report-list">
                <div class="report-item">
                    <div class="report-info">
                        <div class="report-icon">
                            <i class="feather icon-file-text"></i>
                        </div>
                        <div class="report-details">
                            <h4>تقرير المرتبات الشامل</h4>
                            <p>تقرير مفصل بمرتبات الموظفين حسب القسم</p>
                        </div>
                    </div>
                    <a href="{{ route('hr.reports.salaries') }}" class="view-btn">
                        عرض التقرير
                        <i class="feather icon-arrow-left"></i>
                    </a>
                </div>

                <div class="report-item">
                    <div class="report-info">
                        <div class="report-icon">
                            <i class="feather icon-trending-up"></i>
                        </div>
                        <div class="report-details">
                            <h4>تقرير البدلات والخصومات</h4>
                            <p>تفاصيل البدلات والخصومات لكل موظف</p>
                        </div>
                    </div>
                    <a href="{{ route('hr.reports.salaries') }}" class="view-btn">
                        عرض التقرير
                        <i class="feather icon-arrow-left"></i>
                    </a>
                </div>

                <div class="report-item">
                    <div class="report-info">
                        <div class="report-icon">
                            <i class="feather icon-pie-chart"></i>
                        </div>
                        <div class="report-details">
                            <h4>تقرير صافي الرواتب</h4>
                            <p>إجمالي صافي المرتبات حسب الأقسام</p>
                        </div>
                    </div>
                    <a href="{{ route('hr.reports.salaries') }}" class="view-btn">
                        عرض التقرير
                        <i class="feather icon-arrow-left"></i>
                    </a>
                </div>
            </div>
        </div>

        <!-- قسم تقارير المدفوعات -->
        <div class="report-section">
            <div class="section-header">
                <h3>
                    <i class="feather icon-credit-card"></i>
                    تقارير المدفوعات (التحصيل)
                </h3>
            </div>
            <div class="report-list">
                <div class="report-item">
                    <div class="report-info">
                        <div class="report-icon">
                            <i class="feather icon-list"></i>
                        </div>
                        <div class="report-details">
                            <h4>تقرير المدفوعات التفصيلي</h4>
                            <p>تقرير شامل بجميع المدفوعات المسددة</p>
                        </div>
                    </div>
                    <a href="{{ route('hr.reports.payments') }}" class="view-btn">
                        عرض التقرير
                        <i class="feather icon-arrow-left"></i>
                    </a>
                </div>

                <div class="report-item">
                    <div class="report-info">
                        <div class="report-icon">
                            <i class="feather icon-bar-chart-2"></i>
                        </div>
                        <div class="report-details">
                            <h4>تقرير المدفوعات حسب الطريقة</h4>
                            <p>تصنيف المدفوعات (نقدي - بنكي - أخرى)</p>
                        </div>
                    </div>
                    <a href="{{ route('hr.reports.payments') }}" class="view-btn">
                        عرض التقرير
                        <i class="feather icon-arrow-left"></i>
                    </a>
                </div>

                <div class="report-item">
                    <div class="report-info">
                        <div class="report-icon">
                            <i class="feather icon-calendar"></i>
                        </div>
                        <div class="report-details">
                            <h4>التحصيل اليومي</h4>
                            <p>تقرير يومي بالمدفوعات المحصلة</p>
                        </div>
                    </div>
                    <a href="{{ route('hr.reports.payments') }}" class="view-btn">
                        عرض التقرير
                        <i class="feather icon-arrow-left"></i>
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
@stop

@section('js')
@stop
